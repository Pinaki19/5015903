package com.spring_maven.LibraryManagement;


public class LibraryManagementApplication
{
    public static void main( String[] args )
    {
        System.out.println( "\nHello World! from Spring" );
    }
}
